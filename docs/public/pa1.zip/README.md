```
Set-Location -Path \path\to\pa1\
javac -encoding UTF-8 *.java
java BankApp
```
