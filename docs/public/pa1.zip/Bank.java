import java.util.ArrayList;
import java.util.List;

/**
 * 银行类，负责管理多个银行账户
 * TODO: 需要完成所有标记为TODO的方法实现
 */
public class Bank {
    // TODO: 声明私有属性
    // - bankName (String): 银行名称
    // - accounts (List<BankAccount>): 账户列表

    // TODO: 实现构造方法
    public Bank(String bankName) {
        // 初始化银行名称和空的账户列表
    }

    // TODO: 实现添加账户方法重载
    /**
     * 添加新账户（使用默认构造）
     * 
     * @return 新创建的账户
     */
    public BankAccount addAccount() {
        // 创建新账户，添加到列表，返回新账户
        return null; // 临时返回值
    }

    // TODO: 实现添加账户方法重载
    /**
     * 添加新账户（指定持有人）
     * 
     * @param accountHolder 账户持有人
     * @return 新创建的账户
     */
    public BankAccount addAccount(String accountHolder) {
        // 生成账户号码，创建账户，添加到列表
        return null; // 临时返回值
    }

    // TODO: 实现添加账户方法重载
    /**
     * 添加完整信息的账户
     * 
     * @param accountHolder  账户持有人
     * @param initialBalance 初始余额
     * @param accountType    账户类型
     * @return 新创建的账户
     */
    public BankAccount addAccount(String accountHolder, double initialBalance, AccountType accountType) {
        // 生成账户号码，创建账户，添加到列表
        return null; // 临时返回值
    }

    // TODO: 实现查找账户方法
    /**
     * 根据账户号码查找账户
     * 
     * @param accountNumber 账户号码
     * @return 找到的账户，未找到返回null
     */
    public BankAccount findAccount(String accountNumber) {
        // 遍历账户列表查找
        return null; // 临时返回值
    }

    // TODO: 实现删除账户方法
    /**
     * 根据账户号码删除账户
     * 
     * @param accountNumber 账户号码
     * @return 删除是否成功
     */
    public boolean removeAccount(String accountNumber) {
        // 查找账户并删除
        return false; // 临时返回值
    }

    // TODO: 实现显示所有账户方法
    /**
     * 显示银行所有账户信息
     */
    public void displayAllAccounts() {
        // 遍历并显示所有账户的基本信息
    }

    // TODO: 生成唯一账户号码的辅助方法
    /**
     * 生成唯一的账户号码
     * 
     * @return 新的账户号码
     */
    private String generateAccountNumber() {
        // 生成格式为 "BANK-XXXX" 的账户号码
        // XXXX 为4位数字，从0001开始递增
        return ""; // 临时返回值
    }
}