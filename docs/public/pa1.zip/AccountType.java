public enum AccountType {
    CHECKING,  // 支票账户
    SAVINGS,   // 储蓄账户
    CREDIT     // 信用卡账户
}