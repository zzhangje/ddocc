/**
 * 银行账户管理系统主程序
 * TODO: 学生需要完成应用程序逻辑
 */
public class BankApp {
    public static void main(String[] args) {
        // TODO: 创建银行对象

        // TODO: 演示构造方法的使用
        // 1. 使用默认构造方法创建账户
        // 2. 使用带部分参数的构造方法创建账户
        // 3. 使用完整参数的构造方法创建账户

        // TODO: 演示方法重载的使用
        // 1. 测试不同版本的取款方法
        // 2. 测试不同版本的存款方法
        // 3. 测试不同版本的账户信息显示方法

        // TODO: 演示对象之间的交互
        // 1. 执行转账操作
        // 2. 测试equals方法

        // TODO: 创建至少5个测试账户并进行各种操作
        // 包括存款、取款、转账、显示信息等

        // TODO: 输出操作结果，验证程序正确性

        System.out.println("=== 银行账户管理系统演示 ===");

        // 示例测试代码结构（学生需要完善）：
        Bank myBank = new Bank("Java银行");

        // 创建不同类型的账户
        BankAccount account1 = myBank.addAccount("张三", 1000, AccountType.SAVINGS);
        BankAccount account2 = myBank.addAccount("李四", 500, AccountType.CHECKING);

        // 执行各种操作...
        account1.deposit(200);
        account1.withdraw(150);
        account1.transfer(account2, 100);

        // 显示结果...
        myBank.displayAllAccounts();
    }
}