/**
 * 银行账户基类，包含账户的基本属性和行为
 * TODO: 需要完成所有标记为TODO的方法实现
 */
public class BankAccount {
    // TODO: 声明私有属性
    // - accountNumber (String): 账户号码
    // - accountHolder (String): 账户持有人姓名
    // - balance (double): 账户余额
    // - accountType (AccountType): 账户类型
    // - isActive (boolean): 账户是否激活状态

    // TODO: 实现默认构造方法
    /**
     * 默认构造方法
     * 初始化账户为储蓄账户，余额为0，状态为激活
     */
    public BankAccount() {
        // 设置默认值：
        // accountNumber = "未分配"
        // accountHolder = "未知用户"
        // balance = 0.0
        // accountType = AccountType.SAVINGS
        // isActive = true
    }

    // TODO: 实现带参数的构造方法（方法重载）
    /**
     * 带基本参数的构造方法
     * 
     * @param accountNumber 账户号码
     * @param accountHolder 账户持有人
     */
    public BankAccount(String accountNumber, String accountHolder) {
        // 调用this()初始化默认值
        // 然后设置传入的账户号码和持有人
    }

    // TODO: 实现完整参数的构造方法（方法重载）
    /**
     * 完整参数的构造方法
     * 
     * @param accountNumber  账户号码
     * @param accountHolder  账户持有人
     * @param initialBalance 初始余额
     * @param accountType    账户类型
     */
    public BankAccount(String accountNumber, String accountHolder,
            double initialBalance, AccountType accountType) {
        // 初始化所有属性
        // 注意：余额不能为负数，如果initialBalance < 0，设置为0
    }

    // TODO: 实现存款方法
    /**
     * 存款操作
     * 
     * @param amount 存款金额
     * @return 存款是否成功
     */
    public boolean deposit(double amount) {
        // 检查账户是否激活
        // 检查存款金额是否大于0
        // 如果条件满足，增加余额并返回true
        // 否则返回false
        return false; // 临时返回值
    }

    // TODO: 实现取款方法重载 - 基础版本
    /**
     * 取款操作（基础版本）
     * 
     * @param amount 取款金额
     * @return 取款是否成功
     */
    public boolean withdraw(double amount) {
        // 检查账户是否激活
        // 检查取款金额是否大于0且不超过余额
        // 如果条件满足，减少余额并返回true
        // 否则返回false
        return false; // 临时返回值
    }

    // TODO: 实现取款方法重载 - 带透支保护版本
    /**
     * 取款操作（带透支保护）
     * 
     * @param amount         取款金额
     * @param allowOverdraft 是否允许透支
     * @param overdraftLimit 透支额度（仅当allowOverdraft为true时有效）
     * @return 取款是否成功
     */
    public boolean withdraw(double amount, boolean allowOverdraft, double overdraftLimit) {
        // 检查账户是否激活
        // 检查取款金额是否大于0
        // 如果允许透支，检查是否在透支额度内
        // 如果不允许透支，检查是否不超过余额
        // 根据条件执行取款操作
        return false; // 临时返回值
    }

    // TODO: 实现转账方法
    /**
     * 向另一个账户转账
     * 
     * @param targetAccount 目标账户
     * @param amount        转账金额
     * @return 转账是否成功
     */
    public boolean transfer(BankAccount targetAccount, double amount) {
        // 检查两个账户是否都激活
        // 从当前账户取款
        // 如果取款成功，向目标账户存款
        // 如果存款失败，需要回滚取款操作
        return false; // 临时返回值
    }

    // TODO: 实现账户信息显示方法重载
    /**
     * 显示基本账户信息
     */
    public void displayAccountInfo() {
        // 显示账户号码、持有人、类型、余额、状态
    }

    // TODO: 实现账户信息显示方法重载 - 详细版本
    /**
     * 显示详细账户信息
     * 
     * @param showTransactionHistory 是否显示交易历史（模拟）
     */
    public void displayAccountInfo(boolean showDetails) {
        // 如果showDetails为true，显示完整信息包括账户创建时间等
        // 否则只显示基本信息
    }

    // TODO: 实现getter和setter方法
    // 为所有私有属性创建getter和setter
    // 在setter中添加基本的验证逻辑

    // TODO: 重写toString方法
    /**
     * 返回账户的字符串表示
     * 
     * @return 格式化的账户信息
     */
    @Override
    public String toString() {
        // 返回格式化的字符串，包含所有账户信息
        return ""; // 临时返回值
    }

    // TODO: 重写equals方法
    /**
     * 比较两个账户是否相等（基于账户号码）
     * 
     * @param obj 要比较的对象
     * @return 是否相等
     */
    @Override
    public boolean equals(Object obj) {
        // 检查是否为同一对象
        // 检查类型是否相同
        // 比较账户号码
        return false; // 临时返回值
    }
}